def handler(event, context):
    print(f"Received event: {event}")
    return {"statusCode": 200, "body": "OK"}
